# coding= utf-8

import time
import sys
#from EZUart import *


if __name__ == '__main__':
    
	#Object defination
    serial_path1 = sys.argv[1]
    serial_path2 = sys.argv[2]

    #serial_path = '12333'
    print 'uart-----serial_path1 is-----'+serial_path1 + '----\n'
    print 'uart2-----serial_path2 is-----'+serial_path2 + '----\n'





		
